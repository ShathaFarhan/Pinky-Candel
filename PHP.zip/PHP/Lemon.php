<!DOCTYPE html>
<html>

<head>
  <title>Lemonn</title>
  <link rel="stylesheet" href="mystyle.css?<?php echo time(); ?>"/>
  <script src="javascript.js">
  </script>
</head>

<body >

  <table width="100%" border=" 0px">
    <thead>
	<!-- logo -->
	<tr>
        <td colspan="7">
          <!-- <h1>This is Web Page Main title</h1>-->
          <img src="cc1.png" alt="logo" width= "100%" height= "100%">
        </td>
      </tr>
    </thead>
    <tbody>
	<!--menu-->
	<tr >
        <td colspan="2" bgcolor="white" width="50">

          <ul >
            <!-- come back -->
            <li class="liMenu"> <a href="index.html">Home</a> </li>
            <li class="liMenu"><a href="#aboutCandle">About Candle</a></li>
            <li class="liMenu"><a href="#ContactUs">Contact Us</a></li>

          </ul>

        </td>

      </tr>
  
   <!--Lemon Candle--> 
 <tr id="aboutCandle">
 
 <td class="infoPic"><img src="lem01.png" alt="Lemon Candle" style="width: 300.449px; height: 320px;"></td>
 
                    <td >
                        <p class="info"><span ><strong> Lemon<br></strong></span></p>  
						<div class="divInfo">A bright sweet and citrus aroma, inspired by a sweet citrus lemon cake with a hint of coconut. Balanced with musk, sweet balsam and vanilla cream. 
              Vegan Candle Co. Essentials Collection is made with 100% domestically sourced natural soy wax, phthalate-free natural essential oils, skin-safe fragrance oils & lead free
             cotton-paper wicks in a minimalist 9oz. glass jar and gold lid. All labels are biodegradable and printed using eco friendly soy ink. Available in all 8 of our signature Vegan 
             Candle Co. scents, our candles are always vegan, thoughtfully sourced, cruelty-free, sustainable, and hand poured to perfection in Seattle, WA. 
            
                          <!-- unorder list for ingredients -->
                          <br>
                          <p class="info2"><strong>Ingredients:</strong></p><br>
                          <ul>
                             <li onmouseover="handleMouseOver(this)" onmouseout= "handleMouseOut(this)">Lemon</li>
                             <li onmouseover="handleMouseOver(this)" onmouseout= "handleMouseOut(this)">Coconut</li>
                             <li onmouseover="handleMouseOver(this)" onmouseout= "handleMouseOut(this)">Musk</li>
                             <li onmouseover="handleMouseOver(this)" onmouseout= "handleMouseOut(this)">Sweet balsam</li>
                             <li onmouseover="handleMouseOver(this)" onmouseout= "handleMouseOut(this)">Vanilla cream</li>
                           </ul>
            </div>
                  						
                    </td>
	  </tr>

	  <!--forms-->
	  <tr>
  <td colspan="2">
  <div class="message"><strong>Want to order this candle?</strong></div> 

  <p> <span class="error"></span> </p>
 <?php include('insert.php')?> 
    <form action=" <?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">

      <br><br>
<label for="Title"> *Title:</label>
<br>
<select name="Title" id="Title" onfocus="handleOnFoucs(this)" onblur="handleOnBlur(this)">
<option value="Ms.">Ms.</option>
<option value="Mr.">Mr.</option>
<option value="Mrs.">Mrs.</option>
<option value="Miss">Miss</option>
</select>
<br>


<br>


First name: <input type="text" name="fname" placeholder="Your first name.." onfocus="handleOnFoucs(this)" onblur="handleOnBlur(this)"><br>
<span class="error" style="font-size:13px"> <?php echo $fnameErr;?></span>

<br>


Last name: <input type="text" name="lname" placeholder="Your last name.."onfocus="handleOnFoucs(this)" onblur="handleOnBlur(this)"><br>
<span class="error" style="font-size:13px"> <?php echo $lnameErr;?></span>

<br>


Email: <input type="text" name="email" placeholder="Your Email.."onfocus="handleOnFoucs(this)" onblur="handleOnBlur(this)"><br>
<span class="error" style="font-size:13px"> <?php echo $emailErr;?></span>


<br>
Subject : <textarea name="sub" rows="5" cols="30" placeholder="Subject.."onfocus="handleOnFoucs(this)" onblur="handleOnBlur(this)"></textarea> <br>
   <span class="error" style="font-size:13px"> <?php echo $subjectErr;?></span><br>
<br>

Your message : <textarea name="message" rows="10 cols="30" placeholder="Message must be less than 500 letters.."onfocus="handleOnFoucs(this)" onblur="handleOnBlur(this)"></textarea>
      <br>
   <span  class="error" style="font-size:13px" > <?php echo $msgErrr;?></span><br>
<br>

<br>
<br>
<label> * Would you like to subscribe to our shop newsletter?</label>
<br>
      <input type="radio" id="YES" name="likes" value="Yes">
      <label style="color:black;" for="YES">Yes</label>
      <input type="radio" id="NO" name="likes" value="No">
      <label style="color:black;" for="NO">No</label> 
<br>
<br>

<input type="submit" name="submit" value="Submit">
<input type="reset" value="Clear">

<br>
    </form>

 

  </td>

</tr>

    </tbody>

 <!-- footer  -->
 <tfoot id="ContactUs">
	<td colspan="2">
    <div> 
      <p class="Developers"><b>Developers:</b><br><br>
             Shatha Farhan <br>
             Noha Ebrahim <br></p>
        
    <p class="contactUs">Contact us:<br><br><a href="mailto:salfaifi0029@stu.kau.edu.sa"> <img src="email.png" alt="email" width="40px" height="35px"> </a></p>
    </div>
	</td>
	</tfoot>
     
  </table>
</body>

</html>