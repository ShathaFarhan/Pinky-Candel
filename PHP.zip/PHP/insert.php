

<?php
 //connection
  $conn = mysqli_connect("localhost", "root", "", "db_405");
    
  // Check connection
  if($conn === false){
      die("ERROR: Could not connect. " 
          . mysqli_connect_error());
  }

// define var and set to empty value 
$fnameErr = $lnameErr =$emailErr = $subjectErr = $msgErrr = "";

//validation
if ($_SERVER["REQUEST_METHOD"]=="POST"){

   //define variables
    $Title=$fname= $lname =$email= $sub= $message= $likes="";
    $Title = $_POST['Title'];
    $likes = $_POST['likes'];
     $checkfname= $checklname=$checkEmail=$checkSub=$checkMessage=false;

//validation
     if (empty($_POST["fname"])){
         $fnameErr = "please enter a valid name ";
        }
       else {
        if (!preg_match("/^[a-zA-Z-']*$/",$fname)){

         $fnameErr="only lettters and white spaces allowed";
        
        }
        else{
            $fname= $_POST["fname"];
            $checkfname=true;
            
        }

       }
         
        if (empty($_POST["lname"])){
         $lnameErr = "please enter a valid name ";
        }
       else {
        if (!preg_match("/^[a-zA-Z-']*$/",$lname)){
         $lnameErr="only lettters and white spaces allowed";
        }
        else{
            $lname= $_POST["lname"];
            $checklname=true;
        }
       }
                
       
       if (empty($_POST["email"])){
        $emailErr= "enter valid email address";
        
       }
       
       else{
        $email= $_POST["email"];
        $checkEmail=true;
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)){
         $emailErr= "this email incorrect";
        }
       }
       if (empty($_POST["sub"])){
        $subjectErr= "Please enter the subject";
        
       }
       else{
        $sub =$_POST["sub"];
         $checkSub=true;
       }
       
       
        if  (strlen($_POST['message']) > 400 ) {
        $msgErrr = " A maximum of 400 characters is required";
       }
       else{
        $message =$_POST["message"];
        $checkMessage=true;
       }
       
 //DATABASE
 // Performing insert query execution
 if
 ( $checkfname&&$checklname&&$checkEmail&&$checkSub&&$checkMessage){
   
     $sql = "INSERT INTO lemon_info(Title,fname,lname,email,sub,msg,likes) VALUES ('$Title', 
     '$fname','$lname','$email','$sub','$message','$likes')";
     
    
     if(mysqli_query($conn, $sql)){  
      //retrieve query
         error_reporting(0);
         $retrieve_query = "SELECT * from lemon_info where email='". $email ."'";
         $data=mysqli_query($conn, $retrieve_query);
         $total_data=mysqli_num_rows($data);
         $result=mysqli_fetch_assoc($data);
         echo "Thank you ".$result['title']." " .$result['fname'] ." " . $result['lname']. "Your information was submitted successfully";
       } else {
           echo 
      mysqli_error($conn);
       }
     }
    }  

mysqli_close($conn);
  ?>